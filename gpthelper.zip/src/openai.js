
import OpenAI from 'openai';
import config from 'config'
import { createReadStream } from "fs";

class OpenAiService {
    constructor(apiKey) {
        this.openai1 = new OpenAI({ apiKey });
    }


    chat() {

    }
    async transcription(filepath) {
        try {
 
              
            console.log(' response.data')
            
            const audioText = createReadStream(filepath);


            this.openai1.translate({
                engine: 'whisper', // Або 'gpt-3.5-turbo' для швидшого відгуку
                prompt: audioText,
                max_tokens: 150,
              })
                .then(response => {
                  const convertedText = response.choices[0].text;
                  console.log('Конвертований текст:', convertedText);
                })
                .catch(error => {
                  console.error('Помилка при конвертації аудіо в текст:', error);
                });

//             audio_file= open(filepath, "rb")
//             const response  = openai.Audio.transcribe("whisper-1", audio_file)

// console.log(' response.data :: ', response)
              return response.data.text
        } catch (e) {
            console.log('transcription error :: ', e)
        }
    }
}

console.log("API Key:", config.get('OPENAI_KEY')); // Это должно показать ваш ключ API
export const openai = new OpenAiService(config.get('OPENAI_KEY'))
